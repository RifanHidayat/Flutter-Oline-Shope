<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RestFullAPi extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('ModelShope');
	}

	public function index()
	{
	 // 	$response = $this->modelnotes->tampilAll('tb_no',['id_user'=>$this->input->post('id')])->result();
		// echo json_encode($response);
		// header('Content-Type: application/json');
	}
	public function all_produc(){
		$response = $this->modelshope->tampilAll('tb_produc')->result();
		$result["data"]=$response;
		echo json_encode($result);
		header('Content-Type: application/json');
	}
	public function produk_kategori(){
		$response = $this->modelshope->kategori('tb_produc',['kategori'=>$this->input->post('kategori')])->result();
		$result["data"]=$response;
		echo json_encode($result);
		header('Content-Type: application/json');
	}
	public function login(){
	
		$username=$this->input->post('username');
		$password=$this->input->post('password');
		$user=$this->db->get_where('tb_user',['username'=>$username])->row_array();
		// die;
		if ($user){
			if (password_verify($password,$user['password'])){
				$result['value']=1;
				$result['status']="true";
				$result['message']="Berhasil melakukan Login";
				$result['detail']=$user;
				
				header('Content-Type: application/json');
       		
			}else{
				$result['value']=0;
				$result['status']="false";
				$result['message']="Password yang dimasukkan salah";
				header('Content-Type: application/json');
        				
			}

		}else{		
				$result['value']=0;
				$result['statu']="false";
				$result['message']="username yang dimasukan tidak tersedia";
			
				header('Content-Type: application/json');
        
		}
		 echo json_encode($result);


	} 

	public function register(){
	
		$email=$this->input->post('email');
		$username=$this->input->post('username');
	
		$where_email=array('email'=>$email);
		$where_username=array('username'=>$username);
		$cekemail=$this->ModelShope->cek('tb_user',$where_email);
		$cekusername=$this->ModelShope->cek('tb_user',$where_username);
		if ($cekusername->num_rows()>=1){
			$result['value']=2;
			$result['status']="false";
			$result['message']="username Sudah digunakan";


		}else if ($cekemail->num_rows()>=1){
			$result['value']=2;
			$result['status']="false";
			$result['message']="email Sudah digunakan";


		}else{

				$data=[
				'firts_name'=>$this->input->post('first_name'),
				'last_name'=>$this->input->post('last_name'),
				'username'=>$this->input->post('username'),
				'email'=>$this->input->post('email'),
				'telp'=>$this->input->post('telp'),			
				'password'=> password_hash($this->input->post('password'), PASSWORD_DEFAULT)
			];
			$daftar=$this->db->insert('tb_user',$data);
			if ($daftar){

			$result['value']=1;	
			$result['status']="true";
			$result['message']="Berhasil melakukan register";


			}else{
			$result['value']=0;	
			$result['status']="false";
			$result['message']="Gagal melakukan register";
			}
		}
	
			echo json_encode($result);
			header('Content-Type: application/json');
	
	} 
}


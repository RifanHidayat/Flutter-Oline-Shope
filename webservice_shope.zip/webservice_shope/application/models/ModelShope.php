<?php
class ModelShope extends CI_Model{


public function kategori($table,$where){

return $this->db->get_where($table,$where);
}

public function cek($table,$where){
	return $this->db->get_where($table,$where);
}

public function tampilAll($table){

return $this->db->get_where($table);
}

}